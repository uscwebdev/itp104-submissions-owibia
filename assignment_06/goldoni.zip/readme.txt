OTF: Goldoni
Dennis Ludlow 2017 all rights reserved
by Sharkshock 
dennis@sharkshock.net

Buongiorno! Inspired by Italian luxury brands Goldoni is a simple yet elegant titling serif with vertical emphasis. This font was designed with a classic, ultra clean look that 
is liberally spaced to highlight contrast between negative space and the thin nature of the characters. Use Goldoni for a luxury logo, newspaper display, headline, or movie poster. 
Basic and extended latin, numbers, punctuation, European accents, diacritics, alternates, and kerning are included in the complete version. Basic Latin, numbers, and very limited kerning 
and punctuation are included in the demo. 

The complete version is available with purchase of commercial license or $20 via PayPal. Please note that this $20 is for PERSONAL use only and does not constitute a commercial license.

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user
license agreement. You can also visit www.sharkshock.net/license for more info and terms. I also design custom fonts for companies, logos, and many other things. If you'd like to leave 
me a PayPal donation you can use my email address above. Your generosity will be most appreciated! 

Thank you for your support!

visit www.sharkshock.net for more and take a bite out of BORING design!

tags: display, font, typeface, publishing, logo, title, book, cover, Roman,  diacritics, French, Polish, Sharkshock, German, Portuguese, European, Italy, serif, weight, thin,
line, classic, poster, Italia, Europe, Rome, Venice, Florence, style, fashion, luxury, cologne, perfume, title, titling


